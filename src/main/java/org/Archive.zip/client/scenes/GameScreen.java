package org.client.scenes;

public class GameScreen {
}
